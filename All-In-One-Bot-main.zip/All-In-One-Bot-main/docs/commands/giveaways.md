---
description: 7 commands
---

# 🎉 Giveaways

| Command / Slash                   | Description              |
| --------------------------------- | ------------------------ |
| **!giveaway start \<#channel>**   | setup a new giveaway     |
| **!giveaway pause \<messageId>**  | pause a giveaway         |
| **!giveaway resume \<messageId>** | resume a paused giveaway |
| **!giveaway end \<messageId>**    | end a giveaway           |
| **!giveaway reroll \<messageId>** | reroll a giveaway        |
| **!giveaway list \<messageId>**   | list all giveaways       |
| **!giveaway edit \<messageId>**   | edit a giveaway          |
